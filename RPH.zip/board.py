class Board:
    def __init__(self, board):
        self.board = board
    def isValidPos(self, row, col=-1):
        if isinstance(row, list):
            col = row[1]
            row = row[0]
        #print("CHECK POS ["+str(row)+", "+str(col)+"]")
        return row>=0 and col>=0 and row<len(self.board) and col<len(self.board[row])
    def strpos(self, row, col=-1):
        if isinstance(row, list):
            col = row[1]
            row = row[0]
        return "["+str(row)+", "+str(col)+"]"
    # guaranteed to return NEW list containing the two coordinates
    def coord(self, row, col=-1, copy=True):
        if isinstance(row, list):
            return [row[0], row[1]] if copy else row
        elif isinstance(row, tuple):
            return [row[0], row[1]]
        else:
            return [row, col]
    # Performs complete move with placing and reversing stones
    def place(self, pos, player):
        #pos = self.coord(pos, -1, False)
        turned_fields = self.get_claim_stones(pos, player)
        if len(turned_fields)==0:
            raise ValueError("Invalid move at "+self.strpos(pos))
        for field in turned_fields:
            self[field]=player.color
        # do not forget to also actually place th stone
        self[pos] = player.color
    def is_valid_move(self, pos, player):
        turned_fields = self.get_claim_stones(pos, player)
        return len(turned_fields)!=0
    # Returns list of stones turned by placing stone at `stone_pos`
    # if empty list is returned that move is not valid!
    def get_claim_stones(self, stone_pos, player):
        #stone_pos = self.coord(stone_pos, -1, False)
        #print(stone_pos)
        directions = [[0, 1], [1,1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]
        reverse_fields = []
        for direction in directions:
            fields_tmp = self.find_opponent_stones(direction, stone_pos, player)
            # It is noteworthy, that no duplicates need removal
            # because the 'beams' of search never intersect
            reverse_fields += fields_tmp
            #print(fields_tmp)
        #print(reverse_fields)
        #for field in reverse_fields:
        #    print("  - claims ["+str(field[0])+", "+str(field[1])+"]")
        return reverse_fields
    # returns list of stones that will change color if 
    # stone is placed on start
    def find_opponent_stones(self, direction, start, player):
        #print("   Finding enemy stones at "+self.strpos(start)+" in direction "+self.strpos(direction))
        pos = [start[0], start[1]]
        pos[0]+=direction[0]
        pos[1]+=direction[1]
        fields = []
        ended_properly = False
        first_iteration = True
        while self.isValidPos(pos):
            current_color = self[pos];
            if first_iteration:
                if current_color != player.opponent_color:
                    #print("     First stone not enemies' at "+self.strpos(pos))
                    break
            else:
                if current_color == player.color:
                    ended_properly = True
                    break;
                elif current_color == player.neutral_color:
                    #ending if free space was reached
                    break;
            first_iteration = False
            fields.append(self.coord(pos))
            #print("Adding "+self.strpos(pos)+" to list of claimed points.")
            pos[0]+=direction[0]
            pos[1]+=direction[1]
        if(ended_properly):
            #print("   These fields can be claimed: ", end="")
            #print(fields)
            return fields
        else:
            #if len(fields)>0:
            #    print("   Throwing away "+str(len(fields))+" because last field wasn't mine.")
            return []
    def __getitem__(self, key):
        if isinstance(key, list):
            if self.isValidPos(key):
                return self.board[key[0]][key[1]]
            else:
                return None
        else:
            return self.board[key]
    def __setitem__(self, key, value):
        if isinstance(key, list):
            if self.isValidPos(key):
                self.board[key[0]][key[1]] = value
            else:
                raise IndexError("Invalid offset in game board.")
        else:
            if isinstance(value, list) and len(value)==len(self.board[key]):
                self.board[key]=value
            else:
                raise ValueError("Assignment to game board row. Only listof valid length allowed!")
    def __iter__(self):
        return self.board.__iter__()
    def __len__(self):
        return self.board.__len__()
    def printMe(self, p_a, p_b, neutral):
        chars = ["-", "X", "O"]
        roles = [neutral, p_a, p_b]
        rowNo = 0
        colNo = 0
        for row in self:
            if colNo==0:
                print("   ", end="")
                for number in row:
                    print(str((colNo))+" ", end="")
                    colNo+=1
                print("\n", end="")
            print(str(rowNo)+" |", end="")
            rowNo+=1
            for number in row:
                field_type = roles.index(number)
                if field_type<0 or field_type>=len(chars):
                    field_type = 0
                print((chars[field_type])+" ", end="")
            print("\n", end="")